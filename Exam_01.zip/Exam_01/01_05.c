// Задача 01_05 (Исправление ошибок №5):

#include <stdio.h>

int main(void)
{
    int x;
    double pi = 3.141;

    scanf("%d", &x);
    printf("%.2lf", pi * x);

    return 0;
}
