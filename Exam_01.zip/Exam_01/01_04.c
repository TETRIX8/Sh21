// Задача 01_04 (Исправление ошибок №4):

#include <stdio.h>

int main(void)
{
    int left, right;
    
    scanf("%d %d", &left, &right);
    printf("%d", left * right);

    return 0;
}
