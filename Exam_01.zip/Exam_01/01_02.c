// Задача 01_02 (Исправление ошибок №2):

#include <stdio.h>

int main(void)
{
    int x1, x2;
    scanf("%d %d", &x1, &x2);
    printf("%d", x1 * x2);

    return 0;
}
