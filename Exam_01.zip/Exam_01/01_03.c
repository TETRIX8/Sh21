// Задача 01_03 (Исправление ошибок №3):

#include <stdio.h>

int main(void)
{
    int first, second;

    scanf("%d %d", &first, &second);
    printf("%d", first * second);

    return 0;
}
